package com.example.wizsync

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.SocketTimeoutException

/** Ağdaki WiZ ışıkları yayın (broadcast) ile bulur. */
object WizDiscovery {
    private const val PORT = 38899

    private fun broadcastTargets(): List<InetAddress> {
        val out = LinkedHashSet<InetAddress>()
        try {
            out.add(InetAddress.getByName("255.255.255.255"))
        } catch (_: Exception) {
        }
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in ni.interfaceAddresses) {
                    val b = ia.broadcast
                    if (b != null) out.add(b)
                }
            }
        } catch (_: Exception) {
        }
        return out.toList()
    }

    /** IP -> ham cevap */
    fun scan(timeoutMs: Long = 3000): Map<String, String> {
        val found = LinkedHashMap<String, String>()
        try {
            val s = DatagramSocket()
            try {
                s.broadcast = true
                s.soTimeout = 400
                val msgs = listOf(
                    """{"method":"registration","params":{"phoneMac":"AAAAAAAAAAAA","register":false,"phoneIp":"1.2.3.4","id":"1"}}""",
                    """{"method":"getPilot","params":{}}"""
                )
                val targets = broadcastTargets()
                for (m in msgs) {
                    val bytes = m.toByteArray()
                    for (t in targets) {
                        try {
                            s.send(DatagramPacket(bytes, bytes.size, t, PORT))
                        } catch (_: Exception) {
                        }
                    }
                }
                val end = System.currentTimeMillis() + timeoutMs
                val buf = ByteArray(2048)
                while (System.currentTimeMillis() < end) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        val ip = p.address.hostAddress
                        if (ip != null) found[ip] = String(p.data, 0, p.length)
                    } catch (_: SocketTimeoutException) {
                    } catch (_: Exception) {
                        break
                    }
                }
            } finally {
                s.close()
            }
        } catch (_: Exception) {
        }
        return found
    }
}
