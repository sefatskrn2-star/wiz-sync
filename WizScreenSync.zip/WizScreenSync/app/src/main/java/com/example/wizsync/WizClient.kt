package com.example.wizsync

import java.io.Closeable
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

/** WiZ ışıklar yerel ağda UDP 38899 portundan JSON komut kabul eder. */
class WizClient(ip: String) : Closeable {
    private val socket = DatagramSocket()
    private val address = InetAddress.getByName(ip)

    /** r,g,b: 0-255, dimming: 10-100 */
    fun send(r: Int, g: Int, b: Int, dimming: Int) {
        val d = dimming.coerceIn(10, 100)
        val json = """{"id":1,"method":"setPilot","params":{"state":true,"r":$r,"g":$g,"b":$b,"dimming":$d}}"""
        val bytes = json.toByteArray()
        try {
            socket.send(DatagramPacket(bytes, bytes.size, address, 38899))
        } catch (_: Exception) {
        }
    }

    /** Şerit cevap veriyorsa cevabı döndürür, vermiyorsa null. */
    fun query(timeoutMs: Int = 1500): String? {
        return try {
            socket.soTimeout = timeoutMs
            val msg = """{"method":"getPilot","params":{}}""".toByteArray()
            socket.send(DatagramPacket(msg, msg.size, address, 38899))
            val buf = ByteArray(2048)
            val p = DatagramPacket(buf, buf.size)
            socket.receive(p)
            String(p.data, 0, p.length)
        } catch (e: Exception) {
            null
        }
    }

    override fun close() = socket.close()
}
