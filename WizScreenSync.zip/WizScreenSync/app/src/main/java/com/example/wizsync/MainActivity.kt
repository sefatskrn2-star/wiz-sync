package com.example.wizsync

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private val reqCapture = 1001
    private lateinit var ipField: EditText
    private lateinit var status: TextView
    private lateinit var foundBox: LinearLayout

    private val prefs by lazy { getSharedPreferences("wiz", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(120, 40, 120, 40)
        }

        root.addView(TextView(this).apply {
            text = "WiZ Screen Sync 1.1"
            textSize = 28f
            gravity = Gravity.CENTER
        })

        status = TextView(this).apply {
            text = "Önce \"Şeridi bul\"a basın."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 16)
        }
        root.addView(status)

        val findBtn = Button(this).apply {
            text = "Şeridi bul (ağı tara)"
            setOnClickListener { scanNetwork() }
        }
        root.addView(findBtn)

        foundBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(foundBox)

        ipField = EditText(this).apply {
            setText(prefs.getString("ip", ""))
            hint = "IP adresi (192.168.x.x)"
            setSingleLine()
        }
        root.addView(ipField)

        root.addView(Button(this).apply {
            text = "Test (kırmızı yak)"
            setOnClickListener { testStrip() }
        })
        root.addView(Button(this).apply {
            text = "Başlat"
            setOnClickListener { requestCapture() }
        })
        root.addView(Button(this).apply {
            text = "Durdur"
            setOnClickListener { stopSync() }
        })

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        })
        findBtn.requestFocus()
    }

    private fun shortInfo(raw: String): String {
        val mac = Regex("\"mac\":\"([0-9a-fA-F]+)\"").find(raw)?.groupValues?.get(1)
        return if (mac != null) "(MAC …${mac.takeLast(4)})" else ""
    }

    private fun scanNetwork() {
        status.text = "Ağ taranıyor (3 sn)..."
        foundBox.removeAllViews()
        thread {
            val res = WizDiscovery.scan()
            runOnUiThread {
                if (res.isEmpty()) {
                    status.text = "Hiçbir WiZ ışığı cevap vermedi. WiZ uygulamasında Ayarlar > Güvenlik'te " +
                        "yerel iletişimin açık olduğunu ve TV ile şeridin aynı Wi-Fi ağında olduğunu kontrol edin."
                } else {
                    status.text = "${res.size} WiZ cihazı bulundu. Şeridinizi seçin:"
                    for ((ip, raw) in res) {
                        val b = Button(this).apply {
                            text = "$ip  ${shortInfo(raw)}"
                            setOnClickListener { chooseIp(ip) }
                        }
                        foundBox.addView(b)
                    }
                }
            }
        }
    }

    private fun chooseIp(ip: String) {
        ipField.setText(ip)
        prefs.edit().putString("ip", ip).apply()
        status.text = "Seçildi: $ip. Şimdi Test'e basın."
    }

    private fun currentIp(): String? {
        val ip = ipField.text.toString().trim()
        if (ip.isEmpty()) {
            Toast.makeText(this, "Önce IP adresini girin veya şeridi bulun", Toast.LENGTH_SHORT).show()
            return null
        }
        prefs.edit().putString("ip", ip).apply()
        return ip
    }

    private fun testStrip() {
        val ip = currentIp() ?: return
        status.text = "Şeride soruluyor..."
        thread {
            val client = try {
                WizClient(ip)
            } catch (e: Exception) {
                null
            }
            if (client == null) {
                runOnUiThread { status.text = "Geçersiz IP adresi: $ip" }
                return@thread
            }
            val reply = client.query()
            if (reply != null) client.send(255, 0, 0, 100)
            client.close()
            runOnUiThread {
                status.text = if (reply != null) {
                    "Şerit cevap verdi, kırmızı yanmalı. Şimdi Başlat'a basabilirsiniz."
                } else {
                    "Şerit cevap vermedi. IP'yi, yerel iletişimi ve Wi-Fi ağını kontrol edin."
                }
            }
        }
    }

    private fun requestCapture() {
        if (currentIp() == null) return
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    private fun stopSync() {
        startService(Intent(this, SyncService::class.java).setAction(SyncService.ACTION_STOP))
        status.text = "Durduruldu."
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, SyncService::class.java)
                    .putExtra("ip", ipField.text.toString().trim())
                    .putExtra("code", resultCode)
                    .putExtra("data", data)
                startForegroundService(i)
                status.text = "Senkron başladı. Ana ekrana dönüp bir video açın."
            } else {
                status.text = "Ekran yakalama izni verilmedi."
            }
        }
    }
}
