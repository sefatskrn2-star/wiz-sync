package com.example.wizsync

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private val reqCapture = 1001
    private lateinit var ipField: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("wiz", Context.MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(120, 40, 120, 40)
        }

        root.addView(TextView(this).apply {
            text = "WiZ Screen Sync"
            textSize = 28f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "WiZ şeridinin IP adresini girin (ör. 192.168.1.50)"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 16)
        })

        ipField = EditText(this).apply {
            setText(prefs.getString("ip", ""))
            hint = "192.168.x.x"
            setSingleLine()
        }
        root.addView(ipField)

        val testBtn = Button(this).apply {
            text = "Test (kırmızı yak)"
            setOnClickListener {
                val ip = currentIp() ?: return@setOnClickListener
                prefs.edit().putString("ip", ip).apply()
                thread { WizClient(ip).use { it.send(255, 0, 0, 100) } }
                Toast.makeText(this@MainActivity, "Komut gönderildi", Toast.LENGTH_SHORT).show()
            }
        }
        val startBtn = Button(this).apply {
            text = "Başlat"
            setOnClickListener {
                val ip = currentIp() ?: return@setOnClickListener
                prefs.edit().putString("ip", ip).apply()
                val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
            }
        }
        val stopBtn = Button(this).apply {
            text = "Durdur"
            setOnClickListener {
                startService(Intent(this@MainActivity, SyncService::class.java).setAction(SyncService.ACTION_STOP))
            }
        }
        root.addView(testBtn)
        root.addView(startBtn)
        root.addView(stopBtn)
        setContentView(root)
        startBtn.requestFocus()
    }

    private fun currentIp(): String? {
        val ip = ipField.text.toString().trim()
        if (ip.isEmpty()) {
            Toast.makeText(this, "Önce IP adresini girin", Toast.LENGTH_SHORT).show()
            return null
        }
        return ip
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, SyncService::class.java)
                    .putExtra("ip", ipField.text.toString().trim())
                    .putExtra("code", resultCode)
                    .putExtra("data", data)
                startForegroundService(i)
                Toast.makeText(this, "Senkron başladı", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Ekran yakalama izni verilmedi", Toast.LENGTH_LONG).show()
            }
        }
    }
}
