package com.example.wizsync

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import kotlin.math.abs
import kotlin.math.min

class SyncService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.wizsync.STOP"
        private const val CHANNEL = "wizsync"
        private const val W = 64
        private const val H = 36
        private const val MIN_INTERVAL_MS = 120L
        private const val SMOOTH = 0.45f
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var worker: HandlerThread? = null
    private var wiz: WizClient? = null

    private var lastTime = 0L
    private var sr = 0f; private var sg = 0f; private var sb = 0f
    private var lastR = -1; private var lastG = -1; private var lastB = -1; private var lastD = -1

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val ip = intent?.getStringExtra("ip")
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java)
        else @Suppress("DEPRECATION") intent?.getParcelableExtra("data")

        if (ip.isNullOrEmpty() || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        startAsForeground()
        startCapture(ip, code, data)
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "WiZ Screen Sync", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("WiZ Screen Sync çalışıyor")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun startCapture(ip: String, code: Int, data: Intent) {
        wiz = WizClient(ip)
        worker = HandlerThread("wizsync").also { it.start() }
        val handler = Handler(worker!!.looper)

        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data)
        // Android 14+: display oluşturmadan önce callback kayıtlı olmalı
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        reader = ImageReader.newInstance(W, H, PixelFormat.RGBA_8888, 2)
        display = projection!!.createVirtualDisplay(
            "wizsync", W, H, 160,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, handler
        )
        reader!!.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = System.currentTimeMillis()
                if (now - lastTime >= MIN_INTERVAL_MS) {
                    lastTime = now
                    val plane = img.planes[0]
                    val buf = plane.buffer
                    val rowStride = plane.rowStride
                    val pixStride = plane.pixelStride
                    var rs = 0L; var gs = 0L; var bs = 0L
                    for (y in 0 until H) {
                        for (x in 0 until W) {
                            val o = y * rowStride + x * pixStride
                            rs += buf.get(o).toInt() and 0xFF
                            gs += buf.get(o + 1).toInt() and 0xFF
                            bs += buf.get(o + 2).toInt() and 0xFF
                        }
                    }
                    val n = (W * H).toFloat()
                    process(rs / n, gs / n, bs / n)
                }
            } finally {
                img.close()
            }
        }, handler)
    }

    private fun process(r: Float, g: Float, b: Float) {
        // Yumuşatma (titreşimi azaltır)
        sr += (r - sr) * SMOOTH
        sg += (g - sg) * SMOOTH
        sb += (b - sb) * SMOOTH

        val hsv = FloatArray(3)
        Color.RGBToHSV(sr.toInt(), sg.toInt(), sb.toInt(), hsv)
        val value = hsv[2]                      // 0..1 ortalama parlaklık
        hsv[1] = min(1f, hsv[1] * 1.3f)         // renkleri biraz canlandır
        hsv[2] = 1f                              // parlaklığı "dimming" ile ayarlıyoruz
        val rgb = Color.HSVToColor(hsv)

        var cr = Color.red(rgb); var cg = Color.green(rgb); var cb = Color.blue(rgb)
        val dim = (10 + value * 90).toInt()

        // Çok karanlık sahnede renk gürültüsünü önlemek için son rengi koru
        if (value < 0.03f && lastR >= 0) { cr = lastR; cg = lastG; cb = lastB }

        val change = abs(cr - lastR) + abs(cg - lastG) + abs(cb - lastB)
        if (change < 12 && abs(dim - lastD) < 3) return

        lastR = cr; lastG = cg; lastB = cb; lastD = dim
        wiz?.send(cr, cg, cb, dim)
    }

    override fun onDestroy() {
        display?.release()
        reader?.close()
        projection?.stop()
        worker?.quitSafely()
        wiz?.close()
        super.onDestroy()
    }
}
