WiZ Screen Sync 1.1 (Google TV)
Yenilikler: ağdaki WiZ ışıkları otomatik bulma, Test'te şeridin cevap verip vermediğini ekranda gösterme.
1) Android Studio ile bu klasörü açın, Gradle sync bitsin (veya GitHub Actions kullanın).
2) APK'yı TV'ye kurun (eski sürüm varsa önce kaldırın).
3) Uygulamada "Şeridi bul"a basın, şeridi seçin, Test'e basın, sonra Başlat.
