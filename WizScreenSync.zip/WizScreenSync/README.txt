WiZ Screen Sync (Google TV)
1) Android Studio ile bu klasörü açın, Gradle sync bitsin.
2) Build > Build APK(s)  ->  app/build/outputs/apk/debug/app-debug.apk
3) APK'yı USB bellekle TV'ye kurun (TV'de "Bilinmeyen kaynaklar" izni gerekir).
4) Uygulamada WiZ şeridinin IP'sini girin, önce Test'e basın, sonra Başlat.
